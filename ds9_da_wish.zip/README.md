# Explorador FITS

Aplicação Python local, com interface em português no navegador, para visualizar e analisar ficheiros astronómicos. O ambiente virtual encontra-se em `.venv`.

## Abrir

No macOS, abrir `iniciar.command` com duplo clique. Em alternativa, no terminal, dentro desta pasta:

```sh
source .venv/bin/activate
python -m streamlit run app.py --server.address 127.0.0.1
```

Aceder a http://localhost:8501. Para terminar, premir Ctrl+C no terminal.

## Utilização

1. Na barra lateral, usar **Subir** e **Escolher subpasta** para navegar. **Início** abre a pasta pessoal; **Outro caminho** permite indicar diretamente uma pasta. Procurar e selecionar o ficheiro, ou usar **Carregar**.
2. Ajustar escala, cores e contraste na barra lateral. Usar a barra da imagem para ampliar, deslocar ou guardar PNG.
3. Abrir **Analisar imagem**, **Recortar e exportar FITS** ou **Cabeçalho FITS** quando for necessário. A extensão HDU e o plano só aparecem para ficheiros com vários elementos.

As coordenadas da interface começam em zero. O limite final de um recorte é exclusivo. As estatísticas e os perfis referem-se à região após as operações numéricas. As escalas de contraste não alteram os dados exportados.

A exportação FITS contém apenas a HDU selecionada, convertida para imagem de vírgula flutuante, preservando o cabeçalho e ajustando CRPIX ao recorte. Para cubos, preserva todos os planos e aplica-lhes o mesmo recorte/operação. Outras HDUs não são incluídas. WCS com tabelas de distorção externas requer tratamento especializado, não disponibilizado nesta versão.

Os originais nunca são sobrescritos. A aplicação lê os dados em memória: ficheiros grandes podem exigir bastante RAM. A pré-visualização é reduzida para imagens com mais de 1000 píxeis por eixo; a análise e a exportação usam a resolução completa. Carregamentos pelo navegador têm o limite padrão de 200 MB; para ficheiros maiores, usar a pasta local.

## Recriar o ambiente

Python 3.9 ou superior, compatível com as versões indicadas:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

`requirements-lock.txt` regista as versões do ambiente instalado. Para reproduzir esse ambiente na mesma versão de Python/plataforma, usar esse ficheiro em vez de `requirements.txt`.

## Testes

```sh
.venv/bin/python -m pip install pytest
.venv/bin/python -m pytest -q
```

Bibliotecas: [Astropy FITS](https://docs.astropy.org/en/stable/io/fits/), [Streamlit](https://docs.streamlit.io/) e [Plotly](https://plotly.com/python/).
