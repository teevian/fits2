"""Operações FITS independentes da interface; nunca modificam os originais."""
from io import BytesIO
import numpy as np
from astropy.io import fits


def statistics(data):
    values = np.asarray(data, dtype=float)
    values = values[np.isfinite(values)]
    if not values.size:
        return {}
    return dict(pixeis=int(values.size), minimo=float(values.min()),
                maximo=float(values.max()), media=float(values.mean()),
                mediana=float(np.median(values)), desvio=float(values.std()),
                soma=float(values.sum()))


def display_values(data, low, high, scale):
    normalized = np.clip((np.asarray(data, dtype=float) - low) / max(high-low, 1e-30), 0, 1)
    if scale == 'Logarítmica':
        return np.log1p(1000 * normalized) / np.log1p(1000)
    if scale == 'Asinh':
        return np.arcsinh(10 * normalized) / np.arcsinh(10)
    if scale == 'Raiz quadrada':
        return np.sqrt(normalized)
    return normalized


def export_crop(data, header, x0, x1, y0, y1, offset=0., gain=1.):
    """Recorta os dois eixos espaciais, preservando os restantes eixos e WCS."""
    if not (0 <= x0 < x1 <= data.shape[-1] and 0 <= y0 < y1 <= data.shape[-2]):
        raise ValueError('Limites de recorte inválidos.')
    result = (np.array(data[..., y0:y1, x0:x1], dtype=float) - offset) * gain
    hdr = header.copy()
    for key in list(hdr):
        if key in ('BSCALE', 'BZERO', 'BLANK', 'DATAMIN', 'DATAMAX', 'CHECKSUM', 'DATASUM'):
            del hdr[key]
    # Inclui versões alternativas de WCS (CRPIX1A, CRPIX2A, ...).
    for key in list(hdr):
        if key.startswith('CRPIX1'):
            hdr[key] -= x0
        elif key.startswith('CRPIX2'):
            hdr[key] -= y0
    hdr.add_history(f'Crop x=[{x0},{x1}), y=[{y0},{y1}); (data - {offset}) * {gain}')
    buffer = BytesIO()
    fits.PrimaryHDU(result, header=hdr).writeto(buffer, checksum=True)
    return buffer.getvalue()
