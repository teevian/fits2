from io import BytesIO
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from astropy.io import fits
from fits_tools import statistics, display_values, export_crop

st.set_page_config(page_title='Explorador FITS', page_icon='🔭', layout='wide', initial_sidebar_state='expanded')
ROOT = Path(__file__).resolve().parent
DEFAULT_FOLDER = ROOT / 'share-20260922-download'
if 'folder' not in st.session_state:
    st.session_state.folder = str(DEFAULT_FOLDER if DEFAULT_FOLDER.is_dir() else ROOT)


def enter_folder():
    selected = st.session_state.get('subfolder')
    if selected:
        st.session_state.folder = str(Path(st.session_state.folder) / selected)
        st.session_state.subfolder = None


with st.sidebar:
    st.title('🔭 FITS')
    source_mode = st.segmented_control('Origem', ['Pasta', 'Carregar'], default='Pasta', label_visibility='collapsed')
    source = None
    if source_mode == 'Pasta':
        folder = Path(st.session_state.folder)
        nav1, nav2 = st.columns(2)
        if nav1.button('⌂ Início', use_container_width=True):
            st.session_state.folder = str(Path.home())
            st.rerun()
        if nav2.button('↑ Subir', use_container_width=True, disabled=folder.parent == folder):
            st.session_state.folder = str(folder.parent)
            st.rerun()
        st.caption(str(folder))
        try:
            children = sorted((p.name for p in folder.iterdir() if p.is_dir() and not p.name.startswith('.')), key=str.casefold)
            st.selectbox('Entrar numa pasta', children, index=None, placeholder='Escolher subpasta…',
                         key='subfolder', on_change=enter_folder)
            with st.expander('Outro caminho'):
                path = st.text_input('Caminho da pasta', value=str(folder))
                if st.button('Abrir pasta'):
                    destination = Path(path).expanduser()
                    if destination.is_dir():
                        st.session_state.folder = str(destination.resolve())
                        st.rerun()
                    else:
                        st.error('Pasta não encontrada.')
            files = sorted((p for p in folder.iterdir() if p.is_file()
                            and p.name.lower().endswith(('.fits', '.fit', '.fts', '.fits.gz', '.fit.gz', '.fz'))),
                           key=lambda p: p.name.casefold())
            search = st.text_input('Procurar ficheiro', placeholder='Nome…', label_visibility='collapsed')
            files = [p for p in files if search.casefold() in p.name.casefold()]
            if files:
                source = st.selectbox('Ficheiro', files, format_func=lambda p: p.name, label_visibility='collapsed')
                st.caption(f'{len(files)} ficheiros')
            else:
                st.info('Sem ficheiros FITS nesta pasta.')
        except OSError as exc:
            st.error(f'Não foi possível abrir a pasta: {exc}')
    else:
        source = st.file_uploader('Escolher FITS', type=['fits', 'fit', 'fts', 'gz', 'fz'])

if source is None:
    st.info('Escolhe um ficheiro FITS na barra lateral.')
    st.stop()

try:
    stream = source if isinstance(source, Path) else BytesIO(source.getvalue())
    hdus = fits.open(stream, memmap=False)
except Exception as exc:
    st.error(f'Não foi possível ler o FITS: {exc}')
    st.stop()

with hdus:
    name = source.name
    st.subheader(name)
    if len(hdus) > 1:
        index = st.selectbox('Extensão', range(len(hdus)),
                             format_func=lambda i: f'{i} · {hdus[i].name} ({type(hdus[i]).__name__})')
    else:
        index = 0
    hdu = hdus[index]
    header = hdu.header.copy()
    try:
        data = hdu.data
    except Exception as exc:
        st.error(f'Erro ao ler os dados: {exc}')
        st.stop()
    if data is None:
        st.info('Esta extensão não contém dados. Escolhe outra extensão.')
        st.stop()
    if data.dtype.names:
        frame = pd.DataFrame({column: [value.tolist() if isinstance(value, np.ndarray) else value
                                      for value in data[column]] for column in data.dtype.names})
        st.dataframe(frame, width='stretch')
        st.download_button('Descarregar CSV', frame.to_csv(index=False), 'tabela.csv', 'text/csv')
    elif data.ndim == 1:
        st.plotly_chart(go.Figure(go.Scatter(y=data, mode='lines')).update_layout(
            xaxis_title='Píxel', yaxis_title=header.get('BUNIT', 'Valor')), use_container_width=True)
        st.download_button('Descarregar CSV', pd.DataFrame({'pixel': np.arange(data.size),
                          'valor': data}).to_csv(index=False), 'serie.csv', 'text/csv')
    elif data.ndim >= 2 and all(data.shape):
        slices = []
        if data.ndim > 2:
            with st.sidebar:
                for axis, size in enumerate(data.shape[:-2]):
                    slices.append(st.number_input(f'Plano · eixo {data.ndim-axis}', 0, size-1, 0,
                                                   key=f'axis{axis}'))
        plane = np.asarray(data[tuple(slices)] if slices else data, dtype=float)
        height, width = plane.shape
        with st.sidebar:
            st.divider()
            st.caption('Imagem')
            scale = st.selectbox('Escala', ['Linear', 'Asinh', 'Logarítmica', 'Raiz quadrada'])
            color = st.selectbox('Cores', ['Gray', 'Viridis', 'Inferno', 'Cividis', 'Plasma'])
            contrast = st.slider('Contraste · percentis', 0., 100., (1., 99.), step=0.1)
            with st.expander('Limites manuais'):
                manual = st.checkbox('Definir limites')
                if manual:
                    low_manual = st.number_input('Mínimo', value=0.)
                    high_manual = st.number_input('Máximo', value=1.)
        finite = plane[np.isfinite(plane)]
        if not finite.size:
            st.warning('A imagem não contém valores finitos.')
            st.stop()
        low, high = (low_manual, high_manual) if manual else np.percentile(finite, contrast)
        if high <= low:
            st.error('O máximo de contraste deve ser maior que o mínimo.')
            st.stop()
        step = max(1, int(np.ceil(max(plane.shape) / 1000)))
        preview = plane[::step, ::step]
        figure = go.Figure(go.Heatmap(z=display_values(preview, low, high, scale),
            x=np.arange(0, width, step), y=np.arange(0, height, step), customdata=preview,
            colorscale=color, zmin=0, zmax=1, showscale=False,
            hovertemplate='X=%{x}<br>Y=%{y}<br>Valor=%{customdata:.6g}<extra></extra>'))
        figure.update_layout(height=680, xaxis_title='X', yaxis_title='Y',
                             yaxis=dict(scaleanchor='x', scaleratio=1), margin=dict(t=10, b=35, l=35, r=10))
        st.plotly_chart(figure, use_container_width=True, config={'scrollZoom': True,
            'toImageButtonOptions': {'filename': 'fits_visualizacao'}})
        info = statistics(plane)
        st.caption(f'{width} × {height} píxeis · mínimo {info["minimo"]:.4g} · mediana {info["mediana"]:.4g} · máximo {info["maximo"]:.4g}'
                   + (f' · pré-visualização 1:{step}' if step > 1 else ''))
        with st.expander('Analisar imagem'):
            tab1, tab2, tab3 = st.tabs(['Histograma', 'Perfis', 'Estatísticas'])
            with tab1:
                counts, bins = np.histogram(finite, bins=100)
                st.plotly_chart(go.Figure(go.Bar(x=(bins[1:]+bins[:-1])/2, y=counts)).update_layout(
                    xaxis_title='Valor', yaxis_title='Píxeis'), use_container_width=True)
            with tab2:
                col1, col2 = st.columns(2)
                px = col1.number_input('X', 0, width-1, 0)
                py = col2.number_input('Y', 0, height-1, 0)
                st.write(f'Valor: {plane[py,px]:.8g}')
                st.plotly_chart(go.Figure(go.Scatter(x=np.arange(width), y=plane[py,:])).update_layout(
                    xaxis_title=f'Linha Y={py}', yaxis_title='Valor'), use_container_width=True)
                st.plotly_chart(go.Figure(go.Scatter(x=np.arange(height), y=plane[:,px])).update_layout(
                    xaxis_title=f'Coluna X={px}', yaxis_title='Valor'), use_container_width=True)
            with tab3:
                st.dataframe(pd.DataFrame([info]), width='stretch', hide_index=True)
                st.download_button('Descarregar CSV', pd.DataFrame([info]).to_csv(index=False),
                                   'estatisticas.csv', 'text/csv')
        with st.expander('Recortar e exportar FITS'):
            col1, col2, col3, col4 = st.columns(4)
            x0 = col1.number_input('X inicial', 0, width-1, 0)
            x1 = col2.number_input('X final', int(x0)+1, width, width)
            y0 = col3.number_input('Y inicial', 0, height-1, 0)
            y1 = col4.number_input('Y final', int(y0)+1, height, height)
            col1, col2 = st.columns(2)
            offset = col1.number_input('Subtrair', value=0.)
            gain = col2.number_input('Multiplicar por', value=1.)
            st.caption('Coordenadas desde zero; limites finais exclusivos. Em cubos, aplica-se a todos os planos.')
            if st.button('Preparar FITS'):
                output = export_crop(data, header, x0, x1, y0, y1, offset, gain)
                st.download_button('Descarregar FITS', output, Path(name).stem+'_resultado.fits',
                                   'application/fits')
    else:
        st.info('Esta extensão não contém uma imagem ou série suportada.')
    with st.expander('Cabeçalho FITS'):
        search_header = st.text_input('Procurar palavra-chave')
        rows = [dict(Chave=card.keyword, Valor=str(card.value), Comentário=card.comment)
                for card in header.cards]
        st.dataframe(pd.DataFrame([row for row in rows if search_header.casefold() in str(row).casefold()]),
                     width='stretch', hide_index=True)
        st.download_button('Descarregar cabeçalho', header.tostring(sep='\n'), 'header.txt')
